//JS - back to errors in english
user.textrans = null
